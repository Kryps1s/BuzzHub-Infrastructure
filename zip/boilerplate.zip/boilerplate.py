"""boilerplate code for creating lambda functions, actual will be deployed from github actions"""

def lambda_handler(event, context):
    """lambda handler"""
    pass
